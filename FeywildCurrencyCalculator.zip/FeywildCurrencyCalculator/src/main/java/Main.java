public class Main {
    public static void main(String[] args) {
//        System.out.println(FeyNumberConversion.decimalToFeyNum(51));
//        System.out.println(FeyNumberConversion.feyNumToDecimal("225"));

//        System.out.println(FeywildConversionCalculator.trueGoldToFeyCurrency(3840));
        System.out.println(FeywildConversionCalculator.trueFeyToGoldCurrency(365));

//        CalculatorView calculatorView = new CalculatorView();
//        calculatorView.runMainMenu();

//        FeywildConversionCalculator calculator = new FeywildConversionCalculator();
//        calculator.printFeywildCurrencyValues();
//        calculator.currencyExchangeGoldToFeywildMode();
//        calculator.printFeywildCurrencyValues();
//        calculator.trueGoldToFeywildValue(12000);
    }
}